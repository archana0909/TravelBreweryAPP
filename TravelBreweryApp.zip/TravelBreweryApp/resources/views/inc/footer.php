<footer class="bg-dark">
  <section id="main-footer">
    <div class="container">
      <div class="col-sm-3">
        <div>
          <h3><span>TRAVEL&nbsp;</span><span class="footer-logo">BREWERY</span></h3>
        </div>
        <div class="contactnumber">+91-8238566835</div>

        <ul class="social list-inline">
          <li class="list-inline-item">
            <a href="https://www.facebook.com/travelbrewery"><i class="fa  fa-2x fa-facebook"></i></a>
          </li>
          <li class="list-inline-item">

            <a href="https://www.instagram.com/travelbrewery/"><i class="fa fa-2x fa-instagram"></i></a>
          </li>
        </ul>
        <p class="copyright">&copy;2017 TRAVEL BREWERY</p><p class="copyright"> All rights reserved.</p>

      </div>
      <div class="col-sm-3 column">
        <ul class="list_style">
          <li class="nav-head">Company</li>
          <li><a href="http://travelbrewery.com/index.php#about" target="_blank">About</a></li>
            <li><a href="http://travelbrewery.com/index.php#services" target="_blank">Services</a></li>

        </ul>
      </div>
      <div class="col-sm-3 column">
        <ul class="list_style">
          <li class="nav-head">Tours And Blogs</li>
          <li><a href="http://travelbrewery.com/index.php#iti-portfolio" target="_blank">Our Top Tours</a></li>
          <li><a href="http://travelbrewery.com/Blog" target="_blank">Blogs</a></li>
        </ul>
      </div>
      <div class="col-sm-3 column">
        <ul class="list_style">
          <li class="nav-head">Support</li>
          <li><a href="http://travelbrewery.com/index.php#contact" target="_blank">Contact</a></li>
          <li><a href="http://travelbrewery.com/terms-conditions.php" target="_blank">Terms and Conditions</a></li>
        </ul>
      </div>
    </div>
  </div>
  </footer>
