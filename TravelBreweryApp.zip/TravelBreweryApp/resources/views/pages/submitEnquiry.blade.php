
<div class="container-fluid enquiry">
  <div class="row">
    <div class="col-sm-12">
      {!! Form::open(['action' => 'AjaxController@submitEnquiryonIti', 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
              <div class="form-group">
                  {{Form::label('name', 'Name')}}
                  {{Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'Name'])}}
              </div>
              <div class="form-group">
                  {{Form::label('email', 'Email')}}
                  {{Form::text('email', '', ['class' => 'form-control', 'placeholder' => 'Email'])}}
              </div>
              <div class="form-group">
                  {{Form::label('telephone', 'Telephone')}}
                  {{Form::text('telephone', '', ['class' => 'form-control', 'placeholder' => 'Mobile Number(+91-xxxxx-xxxxx)'])}}
              </div>
              <div class="form-group">
                  {{Form::label('query', 'Query')}}
                  {{Form::text('query', '', ['class' => 'form-control', 'placeholder' => 'Type your question here'])}}
              </div>

              <div class="form-group hidden">
                  {{Form::label('tripTitle', 'tripTitle')}}
                  <input class="form-control" type="text" name="tripTitle"  value="<?php echo $_SERVER['REQUEST_URI'] ?>">

              </div>

              {{Form::submit('Submit', ['class'=>'btn btn-primary'])}}

          {!! Form::close() !!}
    </div>
  </div>
</div>
