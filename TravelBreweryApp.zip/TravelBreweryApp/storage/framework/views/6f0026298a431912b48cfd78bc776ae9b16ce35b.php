<?php $__env->startSection('content'); ?>
<script type="text/javascript">
function remove(el){
    $(el).parents(".sub-iti").remove();
}
</script>
<div  class="container" >
  <?php echo Form::open(['action' => 'TourDetailsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>


  <div class="row">
    <div class="col-sm-4">
      <hr class="light">
      <hr class="light">
      <h1>Create Itinerary</h1>
      <div class="form-group">
        <?php echo e(Form::label('title', 'Title')); ?>

        <?php echo e(Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Title'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('headerImg', 'HeaderImage')); ?>

        <?php echo e(Form::text('headerImg', '', ['class' => 'form-control', 'placeholder' => 'HeaderImage'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('price', 'Price')); ?>

        <?php echo e(Form::text('price', '', ['class' => 'form-control', 'placeholder' => 'Price'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('flyTo', 'FlyTo')); ?>

        <?php echo e(Form::text('flyTo', '', ['class' => 'form-control', 'placeholder' => 'FlyTo'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('returnFrom', 'ReturnFrom')); ?>

        <?php echo e(Form::text('returnFrom', '', ['class' => 'form-control', 'placeholder' => 'ReturnFrom'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('startDate', 'TripStartDate')); ?>

        <?php echo e(Form::text('startDate', '', ['class' => 'form-control', 'placeholder' => 'TripStartDate'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('endDate', 'EndDate')); ?>

        <?php echo e(Form::text('endDate', '', ['class' => 'form-control', 'placeholder' => 'EndDate'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('duration', 'TripDuration')); ?>

        <?php echo e(Form::text('duration', '', ['class' => 'form-control', 'placeholder' => 'TripDuration'])); ?>

      </div>
      <!--  -->
      <div class="form-group">
        <?php echo e(Form::label('desc', 'Description')); ?>

        <?php echo e(Form::textarea('desc', '', ['class' => 'form-control', 'placeholder' => 'Description'])); ?>

      </div>
      <hr class="light">
      <hr class="light">
    </div>
    <!-- Add city list -->
    <div class="col-sm-4">
      <hr class="light">
      <hr class="light">
      <h1>Create Itinerary</h1>
      <?php $count=0; ?>
      <div class="iti-parent">
        <div class="sub-iti">
          <?php echo e(Form::label('day','Day Title')); ?>


          <input type="text" class="form-control" name="dayTitle[]" value="" placeholder="type the title of daywise Activity"  />

          <?php echo e(Form::label('day','Day Description')); ?>

          <input type="text" class="form-control" name="dayDesc[]" value="" placeholder="type the description of daywise Activity"  />

          <?php echo e(Form::label('day',' Link to Picture')); ?>


          <input type="text" class="form-control" name="cityImg[]" value="" placeholder="enter the url to image you want to show up in the carousel"  />
          <br>
          <div class="actions"> <button type="button" class="iti-remove btn btn-danger" onclick="remove(this)">Remove</button></div>

        </div>
      </div>

      <!-- Button to add more activity columns -->
      <div class="text-center" id="iti-clone"> <i class="fa fa-2x fa-plus-circle"></i></div>
    </div>
    <div class="col-sm-4">
      <hr class="light">
      <hr class="light">
      <h2>Inclusions</h2>

        <ul>
          <?php foreach ($incl as $inclusion): ?>
            <li class="list_style">
              <label><input type="checkbox" class"form-control" name="tourincl[]" value=<?php echo e($inclusion['id']); ?>>&nbsp;<?php echo e($inclusion['name']); ?></label>
            </li>
          <?php endforeach; ?>
        </ul>
        <hr>
        <h2>Exclusions</h2>
        <ul>
          <?php foreach ($excl as $exclusion): ?>
            <li class="list_style">
              <label><input type="checkbox" class"form-control" name="tourexcl[]" value=<?php echo e($exclusion['id']); ?>>&nbsp;<?php echo e($exclusion['name']); ?></label>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>
    </div>
  </div>
  <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary text-center'])); ?>

  <?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>