
<div class="container-fluid enquiry">
  <div class="row">
    <div class="col-sm-12">
      <?php echo Form::open(['action' => 'AjaxController@submitEnquiryonIti', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

              <div class="form-group">
                  <?php echo e(Form::label('name', 'Name')); ?>

                  <?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'Name'])); ?>

              </div>
              <div class="form-group">
                  <?php echo e(Form::label('email', 'Email')); ?>

                  <?php echo e(Form::text('email', '', ['class' => 'form-control', 'placeholder' => 'Email'])); ?>

              </div>
              <div class="form-group">
                  <?php echo e(Form::label('telephone', 'Telephone')); ?>

                  <?php echo e(Form::text('telephone', '', ['class' => 'form-control', 'placeholder' => 'Mobile Number(+91-xxxxx-xxxxx)'])); ?>

              </div>
              <div class="form-group">
                  <?php echo e(Form::label('query', 'Query')); ?>

                  <?php echo e(Form::text('query', '', ['class' => 'form-control', 'placeholder' => 'Type your question here'])); ?>

              </div>

              <div class="form-group hidden">
                  <?php echo e(Form::label('tripTitle', 'tripTitle')); ?>

                  <input class="form-control" type="text" name="tripTitle"  value="<?php echo $_SERVER['REQUEST_URI'] ?>">

              </div>

              <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>


          <?php echo Form::close(); ?>

    </div>
  </div>
</div>
