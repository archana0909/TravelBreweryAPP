<?php $__env->startSection('content'); ?>
<!-- add a background to it  -->
<section id="iti-all">
  <!--  add a scrollable container here -->
  <div class="container-fluid">
    <!-- <hr class="light"> -->
    <!-- <h1 id="homeHeading" class="text-center">BREWING CUSTOM TOURS FOR YOU</h1>
    <hr/> -->
    <div class="row">
      <div class="col-sm-12" >
        <?php foreach ($tours as $tour): ?>
          <div class="col-sm-3 iti-thumbnail">
            <div class="item">
             <h4 class="iti-title"><a href="itinerary/<?php echo e($tour['id']); ?>"><?php echo e($tour['title']); ?></a>
               <!--  TODO:Add option to edit or delete iti for an admin-->
            <!-- <span class="pull-right">  <i class="iti-like fa fa-heart" style="color:#f1f1f1"></i></span></h4> -->
                <article class="">
                  <a href="itinerary/<?php echo e($tour['id']); ?>"><img class="caption-media" src="<?php echo e($tour['headerImg']); ?>" alt="<?php echo e($tour['title']); ?>"></a>
                  <div class="">
                    <hr class="light">
                    <p class="article-desc">
                      <strong style="color:#3BB5C9;"><?php echo e($tour['tripDuration']); ?> Tour  </strong>&nbsp;| &nbsp;<strong style="color:#2d2121;">Starting @ Rs <?php echo e($tour['price']); ?> only!</strong>
                    </p>
                  </div>
                </article>
              </a>
            </div>

          </div>
        <?php endforeach; ?>
      </div>


      </div>

    </div>
  </section>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>